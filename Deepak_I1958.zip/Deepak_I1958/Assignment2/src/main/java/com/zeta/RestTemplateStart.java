package com.zeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.zeta.models.ApiDetails;

/*
 * Making Project as SpringBoot Application
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, 
		HibernateJpaAutoConfiguration.class })
public class RestTemplateStart {

	public static void main(String[] args) {
		SpringApplication.run(RestTemplateStart.class, args);
	}
	
	//Creating a bean for RestTemplate
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}