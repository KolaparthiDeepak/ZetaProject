package com.zeta.models;

import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * Combination of Data and Support JSONS for /users/id
 */
public class DataSupportDetails {
	@JsonProperty("data")
	private UserDetails data;
	@JsonProperty("support")
	private SupportDetails support;

	public UserDetails getData() {
		return data;
	}

	public void setData(UserDetails data) {
		this.data = data;
	}

	public SupportDetails getSupport() {
		return support;
	}

	public void setSupport(SupportDetails support) {
		this.support = support;
	}
}
