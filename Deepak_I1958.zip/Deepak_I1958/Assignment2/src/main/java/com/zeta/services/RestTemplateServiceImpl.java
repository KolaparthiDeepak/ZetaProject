package com.zeta.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zeta.logging.LogHelper;
import com.zeta.models.*;

/*
 * Making the class as service
 */

@Service
public class RestTemplateServiceImpl implements IRestTemplateService {

	// Connecting Service to RestTemplate through Autowiring
	@Autowired
	RestTemplate template;

	// implementation of endpoints /users
	public ApiDetails getUsers() {

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Application");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			ResponseEntity<ApiDetails> response = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET,
					entity, ApiDetails.class);
			ApiDetails apiDetails = (ApiDetails) response.getBody();
			return apiDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// implementation of endpoints /users/id
	public DataSupportDetails getUserById(int id) {

		String url = "https://reqres.in/api/users/{id}";
		url = url.replace("{id}", String.valueOf(id));
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Application");

			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET, entity, DataSupportDetails.class);
			DataSupportDetails dataSupportDetails = (DataSupportDetails) response.getBody();
			return dataSupportDetails;
		} catch (Exception e) {
			e.printStackTrace();
			LogHelper.log(RestTemplateServiceImpl.class).error("404 Error: " + id + " not avaliable");
			return null;
		}
	}

	// implementation of endpoints /users/page/pageNumber
	public ApiDetails getUsersByPage(int page) {
		String url = "https://reqres.in/api/users?page={page}";
		url = url.replace("{page}", String.valueOf(page));

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Application");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET, entity, ApiDetails.class);
			ApiDetails apiDetails = (ApiDetails) response.getBody();
			return apiDetails;
		} catch (Exception e) {
			LogHelper.log(RestTemplateServiceImpl.class).info("Requesting page " + page + " is empty");
			e.printStackTrace();
			return null;
		}
	}

	// implementation of endpoints post: /users/add
	public PostApiDetails addUser(PostApiDetails user) {

		String url = "https://reqres.in/api/users";

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Application");
			HttpEntity<Object> entity = new HttpEntity<Object>(user, headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.POST, entity, PostApiDetails.class);

			PostApiDetails postApiDetails = (PostApiDetails) response.getBody();
			return postApiDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}