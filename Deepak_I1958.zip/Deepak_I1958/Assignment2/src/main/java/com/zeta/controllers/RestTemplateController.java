package com.zeta.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.zeta.logging.LogHelper;
import com.zeta.models.*;
import com.zeta.services.RestTemplateServiceImpl;

/*
 * Making the class as controller
 */

@RestController
public class RestTemplateController {

	// Connecting Controller to Service through Autowiring
	@Autowired
	RestTemplateServiceImpl service;

	
	// Constructing GET "/users" endpoint
	@RequestMapping(value = "/users", method = RequestMethod.GET, 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ApiDetails getUsers() {
		LogHelper.log(RestTemplateController.class).info("Get Users is invoked.");

		return service.getUsers();
	}

	
	// Constructing GET "/users/id" endpoint
	@RequestMapping(value = "/users/{id}", method = RequestMethod.GET, 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public DataSupportDetails getUserById(@PathVariable int id) {
		LogHelper.log(RestTemplateController.class).info("Get User by id is invoked.");

		return service.getUserById(id);
	}

	
	// Constructing GET "/users/page/pageNumber" endpoint
	@RequestMapping(value = "/users/page/{page}", method = RequestMethod.GET, 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ApiDetails getUserByPage(@PathVariable int page) {
		LogHelper.log(RestTemplateController.class).info("Get Users by page number is invoked.");

		return service.getUsersByPage(page);
	}

	
	// Constructing POST "/users/add" endpoint
	@RequestMapping(value = "/users/add", method = RequestMethod.POST, 
			consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public PostApiDetails addUser(@RequestBody PostApiDetails user) {
		LogHelper.log(RestTemplateController.class).info("Post User is invoked.");
		return service.addUser(user);
	}
}
