package com.zeta.services;

import java.util.List;
import com.zeta.models.*;

/*
 * Service Interface with all endpoints as abstarct classes
 */
public interface IRestTemplateService {
	//method definition for getting all users
	public ApiDetails getUsers();

	//method definition for getting user by id
	public DataSupportDetails getUserById(int id);

	//method definition for getting users by page
	public ApiDetails getUsersByPage(int page);
	
	//method definition for posting a users
	public PostApiDetails addUser(PostApiDetails user);
}
