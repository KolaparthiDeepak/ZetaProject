package com.zeta.models;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * Combination of Data and Support JSONS for /users/page/pageNum
 */
public class ApiDetails {
	@JsonProperty("page")
	private int pageNumber;
	@JsonProperty("per_page")
	private int recordsPerPage;
	@JsonProperty("total")
	private int totalRecords;
	@JsonProperty("total_pages")
	private int totalPages;
	@JsonProperty("data")
	private List<UserDetails> userData;
	@JsonProperty("support")
	private SupportDetails supportData;

	public List<UserDetails> getUserData() {
		return userData;
	}

	public void setUserData(List<UserDetails> userData) {
		this.userData = userData;
	}

	public SupportDetails getSupportData() {
		return supportData;
	}

	public void setSupportData(SupportDetails supportData) {
		this.supportData = supportData;
	}

}
