package com.zeta.logging;

import org.apache.log4j.Logger;

/*
 * Creating a log4j helper class for logging details
 */
public class LogHelper {
	public static Logger log(Class c) {
		Logger l = Logger.getLogger(c);
		return l;
	}
}
