package com.zeta.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zeta.dao.DaoRepository;
import com.zeta.models.Loan;

/*
 * Making the class as Service
 */

@Service
public class LoanServiceImpl implements ILoanService {

	// Connection Service to dao through Autowiring
	@Autowired
	DaoRepository daoRepo;

	// Implementation all CRUD Operations
	
	//Implementation of findall loans
	public List<Loan> getLoan() {
		return daoRepo.findAll();
	}

	//Implementation of findone loans
	public Loan getLoanByNumber(int loanNum) {
		return daoRepo.findOne(loanNum);
	}

	//Implementation of adding loan
	public Loan addNewLoan(Loan l) {
		daoRepo.save(l);
		return l;
	}

	//Implementation of update loan
	public Loan updateLoan(Loan l) {
		daoRepo.save(l);
		return l;
	}

	//Implementation of deleteOne loan
	public void deleteLoanByNumber(int loanNum) {
		daoRepo.delete(loanNum);
	}

	//Implementation of delete all loans
	public void deleteAllLoans() {
		daoRepo.deleteAll();
	}

}
