package com.zeta.services;

import java.util.List;
import com.zeta.models.Loan;

/*
 * Interface for all endpoint methods
 */

public interface ILoanService {
	//method definition for getting all loans
	public List<Loan> getLoan();

	//method definition for getting loan by number
	public Loan getLoanByNumber(int loanNum);

	//method definition for posting new loans
	public Loan addNewLoan(Loan l);

	//method definition for updating loan
	public Loan updateLoan(Loan l);

	//method definition for getting all loans
	public void deleteLoanByNumber(int loanNum);

	//method definition for delete all loans
	public void deleteAllLoans();
}
