package com.zeta.logging;

import org.apache.log4j.Logger;

/*
* Helper method for logging using log4j
 */
public class LogHelper {
	public static Logger log(Class c) {
		Logger l = Logger.getLogger(c);
		return l;
	}
}
