package com.zeta.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zeta.models.Loan;

/*
 * Making my own repository extending JPA repo
 */
@Repository
public interface DaoRepository extends JpaRepository<Loan, Integer> {

}
