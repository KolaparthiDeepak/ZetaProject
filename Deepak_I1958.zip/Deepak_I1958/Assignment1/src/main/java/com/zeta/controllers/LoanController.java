package com.zeta.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.zeta.logging.*;
import com.zeta.models.Loan;
import com.zeta.services.LoanServiceImpl;

/*
 * Making the below class as RestController
 */
@RestController 
public class LoanController {
	// Connecting this controller to service using Autowiring
	@Autowired
	LoanServiceImpl loanService;

	// Constructing Get "/loan/all" endpoint
	@RequestMapping("/loan/all")
	public List<Loan> getLoan() {
		LogHelper.log(LoanController.class).info("Get all loans details is invoked.");

		return loanService.getLoan();
	}

	// Constructing Get "/loan/loanNum" endpoint
	@RequestMapping(value = "/loan/{loanNum}", method = RequestMethod.GET)
	public Loan getLoanByNumber(@PathVariable int loanNum) throws Exception {
		LogHelper.log(LoanController.class).info("Get loan details by loan number is invoked.");

		Loan l = loanService.getLoanByNumber(loanNum);
		return l;
	}

	// Constructing Post "/loan/add" endpoint
	@RequestMapping(value = "/loan/add", method = RequestMethod.POST)
	public Loan addNewLoan(@RequestBody Loan newloan) {
		LogHelper.log(LoanController.class).info("Create new loan method is invoked.");
		return loanService.addNewLoan(newloan);
	}

	// Constructing PUT "/loan/uodate/loanNum" endpoint
	@RequestMapping(value = "/loan/update/{loanNum}", method = RequestMethod.PUT)
	public Loan updateLoan(@RequestBody Loan updemp, @PathVariable int loanNum) throws Exception {
		LogHelper.log(LoanController.class).info("Update loan details by id is invoked.");

		Loan l = loanService.getLoanByNumber(loanNum);
		updemp.setLoanNumber(loanNum);
		return loanService.updateLoan(updemp);
	}

	// Constructing Delete "/loan/delete/loanNum" endpoint
	@RequestMapping(value = "/loan/delete/{loanNum}", method = RequestMethod.DELETE)
	public void deleteLoanByNumber(@PathVariable int loanNum) throws Exception {
		LogHelper.log(LoanController.class).info("Delete loan by loan number is invoked.");

		Loan l = loanService.getLoanByNumber(loanNum);
		loanService.deleteLoanByNumber(loanNum);
	}

	// Constructing Delete "/loan/deleteall" endpoint
	@RequestMapping(value = "/loan/deleteall", method = RequestMethod.DELETE)
	public void deleteAllLoans() {
		LogHelper.log(LoanController.class).info("Delete all loans is invoked.");
		loanService.deleteAllLoans();
	}
}
