package com.zeta.test;
import static org.junit.Assert.*;

import java.sql.Date;
import java.util.List;

import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;
import com.zeta.dao.DaoRepository;
import com.zeta.models.Loan;
import com.zeta.services.LoanServiceImpl;

/*
 * Constructing the Test class
 */
@RunWith(SpringRunner.class)
@SpringBootTest
// @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@FixMethodOrder()
public class LoanJunitTest {
	//connecting this class to repository and service
	@Autowired
	private DaoRepository repo;
	
	@Autowired
	private LoanServiceImpl serv;

	@Test
	@Order(1)
	public void getLoanDetailsTest() {
//		List<Loan> list = repo.findAll();
		List<Loan> list = serv.getLoan();
		assertEquals(3, list.size());
	}

	@Test
	@Order(2)
	public void addNewLoanTest() {
		Loan l = new Loan();
		l.setLoanNumber(109);
		l.setAadharNumber("123456789876");
		l.setFirstname("sree");
		l.setLastName("varma");
		l.setLoanAmount(2344.90);
		l.setLoanStartDate(new Date(2011 - 11 - 11));
		l.setTenure(2.7);
		repo.save(l);
//		assertNotNull(repo.findOne(109));
		assertNotNull(serv.getLoanByNumber(109));
	}

	@Test
	@Order(3)
	public void getLoanByIdTest() {
//		Loan l = repo.findOne(101);
		Loan l = serv.getLoanByNumber(101);
		assertEquals(30.0, l.getTenure(), 10.0);
	}

	@Test
	@Order(4)
	public void updateLoanTest() {
//		Loan l = repo.findOne(101);
		Loan l = serv.getLoanByNumber(101);
		l.setLoanAmount(10000);
		repo.save(l);
		assertNotEquals(500000.00, l.getLoanAmount());
	}

	@Test
	@Order(5)
	public void deleteLoanByIdTest() {
//		repo.delete(109);
		serv.deleteLoanByNumber(109);
		assertEquals(false, repo.exists(109));
	}
}